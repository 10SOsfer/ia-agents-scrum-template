# Configuración global de Claude Code
# Este contenido va en: ~/.claude/CLAUDE.md
# (combínalo con lo que ya tengas ahí)

## Idioma y convenciones de código

- Siempre responde en **español**, sin excepción
- Todos los **comentarios en el código** deben estar en **español**
- Los comentarios explican el "por qué", no el "qué"
- Nombres de **variables, funciones, clases, interfaces, constantes, archivos y endpoints** en **inglés**
- Los **mensajes de error que ve el usuario final** en **español**

## Plantillas disponibles

Tengo registrada la plantilla `equipo-scrum` para crear proyectos de software
con un equipo multi-agente completo que cubre desde la idea hasta el deploy.

## Comando: crear equipo-scrum

Cuando el usuario diga algo como:
- "Crea un nuevo proyecto equipo-scrum para [descripción]"
- "Inicializar equipo-scrum en esta carpeta"
- "Nuevo proyecto con equipo Scrum IA para [idea]"

Debes ejecutar el siguiente proceso:

### Paso 1 — Leer la plantilla base
La plantilla está en: ~/.claude/templates/scrum/
Contiene un CLAUDE.md por cada agente y los archivos de backlog vacíos.

### Paso 2 — Crear la estructura en la carpeta actual
Copiar y adaptar toda la plantilla al contexto del proyecto descrito por el usuario.
Personalizar cada CLAUDE.md de agente con el stack tecnológico y dominio indicados.

### Paso 3 — Inicializar el backlog
Crear los archivos en ./backlog/ con las secciones vacías listas para que el BA las llene.

### Paso 4 — Confirmar al usuario
Mostrar la estructura creada y decirle cómo arrancar:
"Escribe: 'Iniciar fase de requerimientos' para que el equipo empiece a trabajar."

## Notas importantes
- Nunca modificar los archivos en ~/.claude/templates/ — son la plantilla maestra
- Cada proyecto creado es completamente independiente
- El usuario puede tener múltiples proyectos scrum en paralelo sin conflicto
