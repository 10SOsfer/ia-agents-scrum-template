# Equipo Scrum IA — Plantilla Multi-Agente para Claude Code

## Qué es esto

Una plantilla que convierte Claude Code en un **equipo Scrum completo de 8 agentes de IA** que colaboran para llevar una idea desde el concepto hasta producción. Cada agente tiene un rol especializado, sigue protocolos definidos y se coordina con los demás a través de archivos compartidos y señales de completitud.

**No necesitas saber programar para usarla.** Solo describes tu idea y el equipo trabaja.

---

## Equipo de agentes

| Agente | Rol | Fase | Modo |
|--------|-----|------|------|
| **OsferPO** | Product Owner / Orquestador | Todas | Coordina todo el equipo |
| **OsferBA** | Business Analyst | Fase 1 | OsferPO actúa como BA (interactivo) |
| **OsferArq** | Arquitecto de Software | Fase 1 | OsferPO actúa como Arq (interactivo) |
| **OsferUX** | UX Designer / Researcher | Fase 1 | Sub-agente autónomo |
| **OsferDevFront** | Desarrollador Frontend | Fase 1.5 y 2 | Sub-agente autónomo |
| **OsferDevBack** | Desarrollador Backend | Fase 1.5 y 2 | Sub-agente autónomo |
| **OsferQA** | QA Engineer | Fase 2 | Sub-agente autónomo |
| **OsferOps** | DevOps Engineer | Fase 1.5 y 2 | Sub-agente autónomo |

---

## Diagrama del flujo de trabajo

```
=============================================================================
                    FLUJO COMPLETO DEL EQUIPO SCRUM IA
=============================================================================

FASE 1 — REQUERIMIENTOS (antes de cualquier código)
-----------------------------------------------------

  Usuario describe su idea
         |
         v
  ┌─────────────────────────────────┐
  │  PASO 1: OsferPO actua como    │
  │  OsferBA (Business Analyst)    │
  │                                │
  │  - Entiende el dominio         │
  │  - Análisis estratégico         │
  │  - Patrón de Propuesta         │
  │    Enriquecida (A/B/C/D)       │
  │  - Interacción con usuario     │
  │                                │
  │  Output: backlog/epics.md      │
  └───────────────┬─────────────────┘
                  │
                  v
  ┌─────────────────────────────────────────────────────┐
  │  PASO 2a: Preferencias visuales del usuario         │
  │                                                     │
  │  OsferPO pregunta al usuario:                       │
  │  - Tono deseado (profesional/casual/minimalista)    │
  │  - Referencias visuales (productos que le gustan)   │
  │  - Colores de marca o preferencias                  │
  │  - Publico objetivo (tecnico/no tecnico)            │
  │  - Prioridad: diseño visual vs simplicidad          │
  │                                                     │
  │  Output: Brief de diseño para OsferUX               │
  └───────────────────────────┬─────────────────────────┘
                              │
                              v
  ┌─────────────────────────────────────────────────────┐
  │  PASO 2b: Trabajo en PARALELO                       │
  │                                                     │
  │  ┌───────────────────┐   ┌────────────────────────┐ │
  │  │ OsferUX (autonomo)│   │ OsferPO como OsferArq  │ │
  │  │                   │   │ (interactivo)           │ │
  │  │ - Personas        │   │                         │ │
  │  │ - Flujos          │   │ - Stack tecnologico     │ │
  │  │ - Wireframes      │   │ - Patron arquitectura   │ │
  │  │ - Sistema diseno  │   │ - Base de datos         │ │
  │  │ - Prompts IA      │   │ - 3 opciones x decision │ │
  │  │                   │   │ - Verificacion coherencia│ │
  │  │ Lee: epics.md     │   │                         │ │
  │  │    + brief diseño │   │ Lee: epics.md           │ │
  │  │ Output:           │   │ Output:                 │ │
  │  │  ux-flows.md      │   │  architecture.md        │ │
  │  └───────────────────┘   └────────────────────────┘ │
  └───────────────────────────┬─────────────────────────┘
                              │
                              v
  ┌─────────────────────────────────────┐
  │  PASO 3: Validación cruzada          │
  │                                     │
  │  - Verificar UX <-> Arquitectura    │
  │    (SPA vs SSR? REST vs WebSocket?) │
  │  - Resolver conflictos con usuario  │
  │  - Consolidar stories.md           │
  │  - Priorizar (MoSCoW + Valor/Esf.) │
  │  - Verificar criterio INVEST        │
  │                                     │
  │  Output: backlog/stories.md         │
  └───────────────────┬─────────────────┘
                      │
                      v
  ┌─────────────────────────────────┐
  │  PASO 4: Validación del usuario │
  │  (NO se avanza sin aprobación)  │
  └───────────────────┬─────────────┘
                      │
                      v

FASE 1.5 — SPRINT 0 (Bootstrap del proyecto)
----------------------------------------------

  ┌──────────────────────────────────────────────────────┐
  │  PASO 1: OsferOps                                    │
  │  - .gitignore, Dockerfile, docker-compose             │
  │  - Pipeline CI/CD (lint + test + build)               │
  │  - .env.example, estructura de carpetas               │
  │                                                      │
  │  PASO 2: OsferDevBack + OsferDevFront (en paralelo)    │
  │  DevBack:                                             │
  │  - Inicializar proyecto + dependencias                │
  │  - app.config + logger + health endpoints             │
  │  - Schema BD + migración + seed data                  │
  │  DevFront:                                            │
  │  - Inicializar proyecto frontend + dependencias       │
  │  - app.config + logger + design tokens                │
  │  - Layout principal + interceptor HTTP                │
  │                                                      │
  │  PASO 3: Checklist de verificación                    │
  │  (NO se avanza sin verificar todos)                   │
  └───────────────────┬──────────────────────────────────┘
                      │
                      v

FASE 2 — SPRINTS DE DESARROLLO (se repite)
---------------------------------------------

  ┌──────────────────────────────────────────────────┐
  │  1. SPRINT PLANNING                              │
  │     - Seleccionar historias de stories.md        │
  │     - Definir Sprint Goal                        │
  │     - Crear sprint-actual.md                     │
  └──────────────────────┬───────────────────────────┘
                         │
                         v
  ┌──────────────────────────────────────────────────┐
  │  2. DEFINIR CONTRATOS (100% completos)           │
  │     - OsferPO diseña contratos (como OsferArq)   │
  │     - OsferDevBack valida antes de empezar       │
  │     - Endpoints + tipos + errores definidos      │
  └──────────────────────┬───────────────────────────┘
                         │
                         v
  ┌──────────────────────────────────────────────────┐
  │  3. DESARROLLO EN PARALELO                       │
  │                                                  │
  │  ┌─────────────────┐   ┌──────────────────────┐  │
  │  │ OsferDevFront   │   │ OsferDevBack         │  │
  │  │                 │   │                      │  │
  │  │ - Lee wireframes│   │ - Genera tipos en    │  │
  │  │ - Componentes   │   │   ./output/src/types/│  │
  │  │ - Páginas       │   │ - APIs + servicios   │  │
  │  │ - Hooks         │   │ - Modelos + rutas    │  │
  │  │ - Tests         │   │ - Seed data + tests  │  │
  │  │                 │   │                      │  │
  │  │ Lee tipos de    │   │ Owner exclusivo de   │  │
  │  │ DevBack (solo   │   │ ./output/src/types/  │  │
  │  │ lectura)        │   │                      │  │
  │  └─────────────────┘   └──────────────────────┘  │
  └──────────────────────┬───────────────────────────┘
                         │
                         v
  ┌──────────────────────────────────────────────────┐
  │  4. ESPERAR COMPLETITUD                          │
  │     (señales de ambos devs)                       │
  └──────────────────────┬───────────────────────────┘
                         │
                         v
  ┌──────────────────────────────────────────────────┐
  │  5. REVISIÓN CRUZADA                              │
  │     - DevFront revisa endpoints del backend      │
  │     - DevBack revisa llamadas del frontend       │
  │     - Corregir discrepancias ANTES de QA         │
  └──────────────────────┬───────────────────────────┘
                         │
                         v
  ┌──────────────────────────────────────────────────┐
  │  6. QUALITY ASSURANCE (OsferQA)                  │
  │     - Verificar criterios de aceptación           │
  │     - Code review de calidad                     │
  │     - Tests unitarios + integración + E2E         │
  │     - Casos borde + seguridad (OWASP)            │
  │     - Verificar adherencia arquitectónica         │
  │     - Verificar Correlation ID en logs           │
  │     - Verificar cobertura >= 80%                 │
  │                                                  │
  │     Si APRUEBA todo  ──────> paso 7              │
  │     Si RECHAZA ────────────> Protocolo re-trabajo│
  └──────────────────────┬───────────────────────────┘
                         │
              ┌──────────┴──────────┐
              │                     │
              v                     v
  ┌──────────────────┐  ┌───────────────────────────┐
  │ PROTOCOLO        │  │  7. DEPLOY (OsferOps)     │
  │ RE-TRABAJO       │  │     - Staging primero     │
  │                  │  │     - Smoke tests         │
  │ - Max 2 ciclos   │  │     - Producción           │
  │ - Fix solo lo    │  │     - Monitoreo 10 min    │
  │   reportado      │  │     - Deploy parcial si   │
  │ - Si afecta      │  │       hay historias en    │
  │   integracion:   │  │       re-trabajo          │
  │   revision       │  │                           │
  │   cruzada otra   │  │  Rollback disponible:     │
  │   vez            │  │  - Sin migracion: ~5 min  │
  │ - Despues de 2   │  │  - Migr. simple: 5-10 min│
  │   ciclos:        │  │  - Migr. compleja: 15-30  │
  │   escalar al     │  │    (Blue/Green)           │
  │   usuario        │  └───────────┬───────────────┘
  └──────────────────┘              │
                                    v
  ┌──────────────────────────────────────────────────┐
  │  8. SPRINT REVIEW (demo al usuario)              │
  │     - Presentar incremento funcional             │
  │     - Demostrar vs criterios de aceptacion       │
  │     - Recoger feedback                           │
  └──────────────────────┬───────────────────────────┘
                         │
                         v
  ┌──────────────────────────────────────────────────┐
  │  9. RETROSPECTIVA + REFINAMIENTO                 │
  │     - Métricas: velocity, rechazos QA, re-trabajo │
  │     - Qué salió bien / qué mejorar              │
  │     - Acciones concretas                         │
  │     - Re-priorizar backlog                       │
  │     - Refinar historias del próximo sprint       │
  └──────────────────────┬───────────────────────────┘
                         │
                         v
            ┌────────────────────────┐
            │  10. SIGUIENTE SPRINT  │
            │  (volver al paso 1)    │
            └────────────────────────┘


MODO ADOPCIÓN — Proyecto existente (alternativo a Fase 1)
-----------------------------------------------------------

  Usuario dice "adoptar este proyecto"
         |
         v
  ┌─────────────────────────────────────────┐
  │  FASE 0 — Escaneo + Auditoría           │
  │                                         │
  │  OsferPO escanea:                       │
  │  - Código, estructura, dependencias     │
  │  - Git, CI/CD, documentación            │
  │  - Dockerfiles, .env, infraestructura   │
  │                                         │
  │  Auditoría en paralelo:                 │
  │  - OsferDevBack analiza backend         │
  │  - OsferDevFront analiza frontend       │
  │  - OsferQA evalúa calidad y seguridad   │
  │                                         │
  │  Clasificación: FUNCIONA /              │
  │    CON_PROBLEMAS / NO_FUNCIONA / RIESGO │
  └───────────────────┬─────────────────────┘
                      │
                      v
  ┌─────────────────────────────────────────┐
  │  FASE 0.5 — Validación + Extensión      │
  │  (interactiva con el usuario)           │
  │                                         │
  │  - Presenta stack detectado             │
  │  - Presenta funcionalidades encontradas │
  │  - Presenta reporte de salud            │
  │  - Usuario elige qué hacer:             │
  │    agregar / modificar / rediseñar /    │
  │    cambiar stack / arreglar / combinar  │
  └───────────────────┬─────────────────────┘
                      │
                      v
  ┌─────────────────────────────────────────┐
  │  FASE 0.7 — Consolidación               │
  │                                         │
  │  - Backlog con tags: [EXISTENTE] [FIX]  │
  │    [MODIFICACIÓN] [NUEVA]               │
  │  - Priorización sugerida                │
  │  - Validación final con usuario         │
  │                                         │
  │  Entrada al flujo normal según estado:  │
  │  - Sin CI/CD → Fase 1.5 completa       │
  │  - CI/CD parcial → Fase 1.5 parcial    │
  │  - Todo listo → Fase 2 directamente    │
  └───────────────────┬─────────────────────┘
                      │
                      v
              [Flujo normal de sprints]


PROTOCOLO DE TIMEBOXING (cierre de sprint)
-------------------------------------------
Si QA encuentra bugs críticos al final del sprint:

  Opción A: De-scope
    → Desplegar lo aprobado, mover lo bloqueado al siguiente sprint

  Opción B: Extensión controlada
    → Máximo 2 días extra, luego Opción A automática

  Opción C: Sprint fallido
    → No desplegar nada, todo al siguiente sprint
```

---

## Protocolos clave

### Señales de completitud
Cada agente escribe al terminar su trabajo:
```
<!-- SEÑAL:COMPLETADO|[Agente]|[archivo]|[timestamp] -->
```
OsferPO verifica estas señales antes de avanzar al siguiente paso.

### Correlation ID
- **Frontend** genera un UUID v4 por cada acción del usuario
- Se envía como header `X-Correlation-ID` en cada petición HTTP
- **Backend** lo propaga en middleware y lo incluye en todos los logs
- **QA** verifica que la cadena completa funciona

### Contratos antes de código
- OsferPO diseña los contratos de API en `sprint-actual.md`
- OsferDevBack los valida antes de empezar
- Formato pseudo-TypeScript con endpoints, tipos, request/response y errores
- Si no está en el contrato, no se implementa

### Ownership de tipos
- `./output/src/types/` es propiedad **exclusiva** de OsferDevBack
- OsferDevFront los lee pero **nunca los modifica**

### Cobertura de tests
- Los devs son responsables de alcanzar **80% de cobertura**
- OsferQA verifica y rechaza historias que no lo cumplan
- QA escribe tests adicionales para casos borde, seguridad y E2E

---

## Instalación

### Requisitos previos
- [Claude Code CLI](https://docs.anthropic.com/en/docs/claude-code) instalado y configurado
- Plan de Anthropic con acceso a Claude Code

### Paso 1 — Crear la carpeta de plantillas

**Windows (PowerShell):**
```powershell
New-Item -ItemType Directory -Force -Path "$env:USERPROFILE\.claude\templates"
```

**macOS / Linux:**
```bash
mkdir -p ~/.claude/templates
```

### Paso 2 — Copiar la plantilla

**Windows (PowerShell):**
```powershell
Copy-Item -Recurse -Force .\scrum-template "$env:USERPROFILE\.claude\templates\scrum"
```

**macOS / Linux:**
```bash
cp -r ./scrum-template ~/.claude/templates/scrum
```

### Paso 3 — Agregar el comando global

El archivo `INSTALL_GLOBAL_claude.md` contiene las instrucciones que debes agregar a tu `~/.claude/CLAUDE.md` (el archivo de configuración global de Claude Code).

**Si ya tienes un `~/.claude/CLAUDE.md`:**
Abre el archivo y agrega el contenido de `INSTALL_GLOBAL_claude.md` al final.

**Si NO tienes `~/.claude/CLAUDE.md`:**

Windows (PowerShell):
```powershell
Copy-Item .\scrum-template\INSTALL_GLOBAL_claude.md "$env:USERPROFILE\.claude\CLAUDE.md"
```

macOS / Linux:
```bash
cp ./scrum-template/INSTALL_GLOBAL_claude.md ~/.claude/CLAUDE.md
```

### Paso 4 — Verificar

**Windows (PowerShell):**
```powershell
Get-ChildItem "$env:USERPROFILE\.claude\templates\scrum\scrum-template\agents"
```

**macOS / Linux:**
```bash
ls ~/.claude/templates/scrum/scrum-template/agents/
```

Debes ver: `architect/  business-analyst/  dev-backend/  dev-frontend/  devops/  orchestrator/  qa/  ux/`

---

## Uso

### Modo 1 — Crear un nuevo proyecto desde cero

```bash
# 1. Crear carpeta del proyecto
mkdir mi-proyecto
cd mi-proyecto

# 2. Abrir Claude Code
claude

# 3. Decirle que cree el proyecto
> Crea un nuevo proyecto equipo-scrum para [describe tu idea]
```

Claude Code copiará la plantilla, creará la estructura y te dirá cómo arrancar.

### Modo 2 — Adoptar un proyecto existente

```bash
# 1. Ir a la carpeta del proyecto existente
cd mi-proyecto-existente

# 2. Abrir Claude Code
claude

# 3. Decirle que adopte el proyecto
> Adoptar este proyecto con equipo-scrum
> Integrar equipo scrum a este proyecto
```

El equipo ejecutará el **Modo Adopción**:
1. **Fase 0 — Escaneo**: analiza código, estructura, tests, dependencias, CI/CD
2. **Fase 0 — Auditoría técnica**: los devs y QA evalúan la salud del código en paralelo (clasifica como FUNCIONA / CON_PROBLEMAS / NO_FUNCIONA / RIESGO_SEGURIDAD)
3. **Fase 0.5 — Validación interactiva**: te presenta lo encontrado para que confirmes, corrijas y extiendas (agregar funcionalidades nuevas, modificar existentes, rediseñar UI, cambiar stack, arreglar lo roto)
4. **Fase 0.7 — Consolidación**: genera el backlog con historias clasificadas:
   - `[EXISTENTE]` — ya funciona, solo se documenta
   - `[FIX]` — rota o con problemas, hay que corregir
   - `[MODIFICACIÓN]` — funciona pero el usuario quiere cambiarla
   - `[NUEVA]` — no existe, hay que construirla

Después de la consolidación, el proyecto entra al flujo normal (Fase 1.5 o Fase 2 según lo que ya tenga listo).

**Principio fundamental**: el código existente NO cambia de ubicación ni de estructura. La capa de gestión Scrum se monta encima.

### Comandos dentro del proyecto

| Comando | Qué hace |
|---------|----------|
| "Iniciar fase de requerimientos" | BA + Arquitecto + UX trabajan en la Fase 1 |
| "Adoptar este proyecto" | Escanea proyecto existente y monta equipo Scrum |
| "Revisar el backlog" | Muestra historias priorizadas |
| "Iniciar sprint 1" | Selecciona historias y lanza desarrollo |
| "Estado del sprint" | Muestra progreso actual |
| "Correr QA" | QA revisa todo lo producido |
| "Hacer deploy a staging" | DevOps empaca y despliega |
| "Retrospectiva del sprint" | Documenta aprendizajes |

---

## Estructura de archivos del proyecto creado

```
mi-proyecto/
├── CLAUDE.md                         <-- Orquestador (OsferPO) — compacto
├── .claude/settings.json             <-- Permisos del proyecto
├── agents/
│   ├── business-analyst/CLAUDE.md    <-- OsferBA
│   ├── architect/CLAUDE.md           <-- OsferArq
│   ├── ux/CLAUDE.md                  <-- OsferUX
│   ├── dev-frontend/CLAUDE.md        <-- OsferDevFront
│   ├── dev-backend/CLAUDE.md         <-- OsferDevBack
│   ├── qa/CLAUDE.md                  <-- OsferQA
│   ├── devops/CLAUDE.md              <-- OsferOps
│   └── orchestrator/                 <-- Detalle del orquestador (bajo demanda)
│       ├── phase1-requirements.md    <-- Fase 1: BA + Arq + UX + preferencias
│       ├── phase1.5-sprint0.md       <-- Fase 1.5: Bootstrap del proyecto
│       ├── phase2-sprints.md         <-- Fase 2: Ejecución por sprints
│       ├── adoption-mode.md          <-- Modo Adopción (proyectos existentes)
│       ├── contracts.md              <-- Formato de contratos y tipos
│       ├── rework.md                 <-- Protocolo de re-trabajo
│       └── hotfix.md                 <-- Protocolo de hotfix
├── backlog/
│   ├── epics.md                      <-- Épicas y user stories
│   ├── architecture.md               <-- Decisiones técnicas
│   ├── ux-flows.md                   <-- Flujos y wireframes
│   ├── stories.md                    <-- Backlog priorizado
│   ├── sprint-actual.md              <-- Sprint en curso
│   ├── retro.md                      <-- Retrospectivas
│   ├── bugs.md                       <-- Registro de bugs
│   └── incidents.md                  <-- Incidentes de producción
├── templates/                        <-- Templates de archivos de backlog
├── output/                           <-- Código generado
│   ├── src/
│   │   ├── components/               <-- OsferDevFront
│   │   ├── pages/                    <-- OsferDevFront
│   │   ├── hooks/                    <-- OsferDevFront
│   │   ├── routes/                   <-- OsferDevBack
│   │   ├── services/                 <-- OsferDevBack
│   │   ├── models/                   <-- OsferDevBack
│   │   └── types/                    <-- OsferDevBack (owner exclusivo)
│   ├── seeds/                        <-- Datos de prueba
│   └── tests/
│       ├── qa/                       <-- Tests de OsferQA
│       └── fixtures/                 <-- Fixtures de testing
├── infrastructure/                   <-- Terraform, Pulumi, CDK
├── docker/                           <-- Dockerfiles, docker-compose
└── .github/workflows/                <-- Pipelines CI/CD
```

---

## Personalización

Puedes crear variantes de la plantilla para diferentes tipos de proyectos:

```
~/.claude/templates/scrum-mobile/     → Equipo enfocado en React Native
~/.claude/templates/scrum-api/        → Solo backend, sin frontend
~/.claude/templates/scrum-startup/    → Versión más ligera para MVPs rápidos
~/.claude/templates/scrum-fullstack/  → Full-stack con SSR (Next.js, Nuxt, etc.)
```

---

## Arquitectura de tokens optimizada

El CLAUDE.md principal del orquestador es **compacto** (~160 líneas) para minimizar el costo de tokens por request. El detalle de cada fase se carga **bajo demanda** desde archivos separados en `agents/orchestrator/`:

| Archivo | Se carga cuando... |
|---------|-------------------|
| `phase1-requirements.md` | Inicia Fase 1 de requerimientos |
| `phase1.5-sprint0.md` | Inicia Sprint 0 |
| `phase2-sprints.md` | Inicia un sprint de desarrollo |
| `adoption-mode.md` | Se adopta un proyecto existente |
| `contracts.md` | Se definen contratos de API |
| `rework.md` | QA rechaza historias |
| `hotfix.md` | Bug crítico en producción |

---

## Notas importantes

- **Nunca modificar** los archivos en `~/.claude/templates/scrum/` — son la plantilla maestra
- Cada proyecto creado es **completamente independiente**
- Puedes tener **múltiples proyectos** scrum en paralelo sin conflicto
- La plantilla es **agnóstica al stack** — se adapta al framework que elijas durante la Fase 1
- Soporta **proyectos nuevos** (desde cero) y **proyectos existentes** (Modo Adopción)
- El idioma de trabajo es **español** (respuestas, comentarios, documentación)
- Los nombres de **variables, funciones y archivos** van en **inglés**

---

## Créditos

Creado por **Osfer** con Claude Code (Anthropic).
Versión: 2.2 — Marzo 2026
